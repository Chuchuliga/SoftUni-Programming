window.addEventListener('load', solution);

function solution() {
  //TODO...
}


    
    
