window.addEventListener('load', solve);

function solve() {
//TODO...
}




